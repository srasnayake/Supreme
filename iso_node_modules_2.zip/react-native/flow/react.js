// temporary patches for React.Component and React.Element
declare var ReactComponent: typeof React$Component;
declare var ReactElement: typeof React$Element;
