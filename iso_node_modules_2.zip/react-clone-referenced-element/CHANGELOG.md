# Changelog

## 1.1.0
- Added a TypeScript declaration file that matches the type declaration of `React.cloneElement`
- Changed from `let` to `const` for required modules

## 1.0.1
- Removed `peerDependencies` definition since it's noisier than it is useful
