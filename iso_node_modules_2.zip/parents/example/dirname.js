var parents = require('../');
var dirs = parents(__dirname);
console.dir(dirs);
